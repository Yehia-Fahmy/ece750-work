# ECE 750T Assignment 2 — Documentation audit

Completed example submission: **Florence-2-base**, assessed for drafting descriptions of campus photographs for a university website.

The submission uses the supplied template's three sections, 11-point text and 1-inch margins. The executive summary occupies pages 1–2, including its identifying header. References and the instructor-example AI disclosure occupy page 3. The header identifies an example rather than a real student.

## Hand-in files

| Destination | Files to upload |
| --- | --- |
| **LEARN Dropbox** | [`a2-review.pdf`](a2-review.pdf), the complete three-page report |
| **Crowdmark — Question 1: Context** | [`crowdmark/q1-context.png`](crowdmark/q1-context.png) |
| **Crowdmark — Question 2: Critique** | [`crowdmark/q2-critique-01.png`](crowdmark/q2-critique-01.png), then [`crowdmark/q2-critique-02.png`](crowdmark/q2-critique-02.png) |
| **Crowdmark — Question 3: Proposed changes** | [`crowdmark/q3-proposed-changes.png`](crowdmark/q3-proposed-changes.png) |

The critique continues on page 2, so both Question 2 images are required. Screenshots were rendered from the final PDF; every section word is covered exactly once, in reading order.

The handout requires both submission destinations, by **October 19 at 11:59pm ET**. No supplemental files are needed for this submission: upload the PDF directly to LEARN. LaTeX source is not required. No course-site uploads have been performed.

