# ECE 750T A1 starter

Use Python 3.12 or 3.13. The dependencies were tested with Python 3.13 on CPU.
From this directory:

```sh
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python data.py
python train.py --alpha 0 --seed 0 --out runs/a0
```

Complete `correlations`, `metrics`, and `dp_penalty` in `student.py`. Baseline
training works before completing these functions. Evaluation requires `metrics`;
positive-alpha training requires `dp_penalty`.

```sh
python check_metrics.py
python evaluate.py runs/a0
python train.py --alpha 1 --seed 0 --out runs/a1
python evaluate.py runs/a1
```

The value 1 is just a command example. Choose your alpha range as described in
Question 1.4. Keep the seed and supplied training settings fixed across strengths.
Make the three test-metric plots using your own analysis script. Matplotlib is
included in `requirements.txt`. No repeated-seed study or calibration plot is required.

Each run saves `test.npz` (scores, labels, groups, and original row indices),
`test-metrics.json` after evaluation, `config.json`, `history.json`, model weights,
and preprocessing statistics. A run refuses to overwrite an existing directory.
`history.json` records the training objective by epoch. Use the test data only
for evaluation; do not fit preprocessing or model parameters on it.

## Data interface

`from data import load_data` gives access to `(splits, preprocessing)`.
`splits['train']` and `splits['test']` contain `raw_x`, standardized `x`, binary
`y`, binary `a`, and original row `ids`. `preprocessing['names']` gives feature
names. All arrays within a split and its saved predictions have aligned row order.
Use `raw_x` for correlations and `score >= 0.5` for binary predictions.

The original train/test split is unchanged: 32,561/16,281 rows. Standardization
uses only the training set. `a=0` is `Female`, `a=1` is `Male`, and `y=1` is
income above US$50,000. The loader removes both explicit sex columns, leaving
111 features. The last header entry is the target name, not an input column.

The data are from the original instructor repository at revision
`ad3a9e43792e482f63fefc73b40695513901ed15`:
https://github.com/ecreager/csc2541-f19/tree/ad3a9e43792e482f63fefc73b40695513901ed15/assignment1/adult

The loader checks hashes and the group encoding. Header spellings are retained
from the original files.

## Submission

Include the completed starter, clearly named scripts for the coding questions,
a README with reproduction commands, run configurations, and the small result
tables used in your answers. Exclude `data/`, `.venv/`, `__pycache__/`, and model
checkpoints. Submit written answers separately as directed in the handout.
