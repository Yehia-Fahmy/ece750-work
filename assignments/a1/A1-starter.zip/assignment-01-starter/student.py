"""Complete these three functions. See the handout for definitions."""
import numpy as np
import torch


def correlations(x: np.ndarray, target: np.ndarray) -> np.ndarray:
    """Return signed Pearson correlations, one per column of x.

    x has shape (n, d); target has shape (n,). Return shape (d,).
    Return np.nan for a constant feature or constant target. Rank by absolute
    correlation outside this function, breaking ties by feature-column index.
    """
    raise NotImplementedError("Question 1.1: implement correlations")


def metrics(y: np.ndarray, score: np.ndarray, a: np.ndarray) -> dict:
    """Compute metrics over a complete split, using prediction = score >= 0.5.

    All inputs have shape (n,). Return a JSON-serializable dictionary:
      accuracy, rw_accuracy, dp_gap,
      groups: {'0': {n, accuracy, positive_rate},
               '1': {n, accuracy, positive_rate}}.
    Use None for undefined rates and any gap or average depending on one.
    Counts must be Python ints; defined rates must be Python floats.
    Do not average batch-level metrics.
    """
    raise NotImplementedError("Question 1.2: implement metrics")


def dp_penalty(score: torch.Tensor, a: torch.Tensor) -> torch.Tensor:
    """Return a differentiable scalar penalty; score and a have shape (batch,).

    score contains sigmoid probabilities, not logits or thresholded labels.
    Choose and explain your penalty in Question 1.4. The caller handles batches
    missing a group; you may assume both groups are present here.
    """
    raise NotImplementedError("Question 1.4: design and implement a DP penalty")
